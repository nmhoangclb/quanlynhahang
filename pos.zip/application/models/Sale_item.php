<?php

class Sale_item extends ActiveRecord\Model {

   public static $table_name = 'zarest_sale_items';

}

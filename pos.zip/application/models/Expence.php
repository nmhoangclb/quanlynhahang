<?php

class Expence extends ActiveRecord\Model {

   public static $table_name = 'zarest_expences';
}

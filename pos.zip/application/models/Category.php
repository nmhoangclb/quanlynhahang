<?php

class Category extends ActiveRecord\Model {

   public static $table_name = 'zarest_categories';
}

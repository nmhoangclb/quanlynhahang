<?php

class Customer extends ActiveRecord\Model {

   public static $table_name = 'zarest_customers';
}

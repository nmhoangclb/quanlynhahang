<?php

class Supplier extends ActiveRecord\Model {

   public static $table_name = 'zarest_suppliers';
}

<?php

class Register extends ActiveRecord\Model {

   public static $table_name = 'zarest_registers';

}
